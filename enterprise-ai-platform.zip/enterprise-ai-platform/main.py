from applications.incident_assistant import run_incident_assistant

def main() -> None:
    """Start the Enterprise AI Platform."""
    print("=" * 50)
    print("Enterprise AI Platform")
    print("=" * 50)

    run_incident_assistant()


if __name__ == "__main__":
    main()