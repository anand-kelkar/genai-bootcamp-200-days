
class Incident:
    def __init__(self,incident_number,application,error_message,business_impact):
        self.incident_number = incident_number
        self.application = application
        self.error_message = error_message
        self.business_impact = business_impact

