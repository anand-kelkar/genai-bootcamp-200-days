class Embedding:
    pass