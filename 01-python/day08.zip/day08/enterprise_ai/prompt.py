class Prompt:
    pass