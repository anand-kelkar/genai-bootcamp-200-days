class Token:
    pass