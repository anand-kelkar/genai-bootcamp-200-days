class CommonUtils:
    pass