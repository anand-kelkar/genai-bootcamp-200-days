class GlobalConfig:
    pass