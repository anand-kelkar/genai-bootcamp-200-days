class HealthPolicy:
    pass