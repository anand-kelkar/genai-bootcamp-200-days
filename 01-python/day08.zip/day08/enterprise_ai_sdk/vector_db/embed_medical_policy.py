class EmbedMedicalPolicy:
    pass