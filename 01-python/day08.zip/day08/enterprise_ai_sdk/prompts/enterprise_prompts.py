class EnterprisePrompts:
    pass