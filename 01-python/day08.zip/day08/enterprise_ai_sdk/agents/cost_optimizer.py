class CostOptimizer:
    pass