class OpenAIClient:
    pass